// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · data/fakeApi.ts
// │ Async fake API. Swap the // REAL: line for fetch() and it's production.
// └──────────────────────────────────────────────────────────────
export type Account = { id: string; holder: string; iban: string; balance: string; type: string };
export type Txn = { id: string; merchant: string; amount: string; date: string };

const DB: Account[] = [
  { id: 'acc_01', holder: 'Aoife Byrne',   iban: 'IE29 AIBK …78', balance: '€4,182.66',  type: 'Operating' },
  { id: 'acc_02', holder: 'Bob Callaghan', iban: 'IE64 IRCE …78', balance: '€11,904.10', type: 'Savings' },
  { id: 'acc_03', holder: 'Ciara Doyle',   iban: 'IE12 BOFI …78', balance: '€712.44',    type: 'Current' },
];

const TXNS: Record<string, Txn[]> = {
  acc_01: [
    { id: 't1', merchant: 'Ryanair',       amount: '-€89.99',  date: '12 Jul' },
    { id: 't2', merchant: 'Dunnes Stores', amount: '-€47.20',  date: '11 Jul' },
    { id: 't3', merchant: 'Salary',        amount: '+€2,400',  date: '01 Jul' },
  ],
  acc_02: [{ id: 't4', merchant: 'Transfer in', amount: '+€500', date: '10 Jul' }],
  acc_03: [{ id: 't5', merchant: 'Circle K', amount: '-€60.00', date: '09 Jul' }],
};

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function getAccounts(): Promise<Account[]> {
  await wait(600);
  return DB;                                        // REAL: fetch('/api/accounts')
}

export async function getAccount(id: string): Promise<Account> {
  await wait(600);
  const a = DB.find((x) => x.id === id);
  if (!a) throw new Response(`Account ${id} not found`, { status: 404, statusText: 'Not Found' });
  return a;                                         // REAL: fetch(`/api/accounts/${id}`)
}

// A DELIBERATELY SLOW endpoint (1.8s) to make streaming visibly worthwhile.
export async function getTransactions(id: string): Promise<Txn[]> {
  await wait(5800);
  return TXNS[id] ?? [];
}
