// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · router.tsx — loaders attached to routes
// │ Notice: the loader is a PROPERTY of the route, sitting right next
// │ to its Component. Data and view are declared together.
// └──────────────────────────────────────────────────────────────
import { createBrowserRouter } from 'react-router';
import { Shell } from './Shell';
import { Menu } from './pages/Menu';
import RouteError from './pages/RouteError';

import TheUseEffectWay from './demos/01-the-useeffect-way';
import TheLoaderWay, { accountsLoader } from './demos/02-the-loader-way';
import LoaderWithParams, { accountLoader } from './demos/03-loader-with-params';
import PendingUI, { pendingLoader } from './demos/04-pending-ui';
import StreamingAwait, { streamingLoader } from './demos/05-streaming-await';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Shell,
    ErrorBoundary: RouteError,
    children: [
      { index: true, Component: Menu },

      // 01 — no loader; it fetches inside the component the old way.
      { path: 'useeffect', Component: TheUseEffectWay },

      // 02 — loader runs before render.
      { path: 'loader', Component: TheLoaderWay, loader: accountsLoader },

      // 03 — loader receives params; a bad id throws to ErrorBoundary.
      { path: 'detail/:id', Component: LoaderWithParams, loader: accountLoader },

      // 04 — same loader, but the page reads useNavigation for a pending bar.
      { path: 'pending', Component: PendingUI, loader: pendingLoader },

      // 05 — loader returns a pending promise; page streams it with <Await>.
      { path: 'stream/:id', Component: StreamingAwait, loader: streamingLoader },
    ],
  },
]);
