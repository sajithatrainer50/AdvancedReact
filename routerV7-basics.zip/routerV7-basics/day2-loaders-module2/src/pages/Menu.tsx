import { Link } from 'react-router';
export function Menu() {
  return (
    <div>
      <h2>Module 2 — data loading</h2>
      <p className="hint">The module where the spinner disappears. Predict before each.</p>
      <ol className="note" style={{ lineHeight: 2 }}>
        <li><Link to="/useeffect">01 The useEffect way</Link> — how you fetch today (the "before")</li>
        <li><Link to="/loader">02 The loader way</Link> — data before render (the "after")</li>
        <li><Link to="/detail/acc_01">03 Loader with params</Link> — fetch the right record; 404 routes away</li>
        <li><Link to="/pending">04 Pending UI</Link> — useNavigation, one spinner app-wide</li>
        <li><Link to="/stream/acc_01">05 Streaming with Await</Link> — instant page, slow data streams in (latest)</li>
      </ol>
    </div>
  );
}
