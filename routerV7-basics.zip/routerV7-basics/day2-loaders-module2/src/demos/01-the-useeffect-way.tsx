// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · 01-the-useeffect-way.tsx
// │ ONE IDEA: the way you fetch TODAY. Three states, a mount guard,
// │           and the component renders EMPTY before data arrives.
// └──────────────────────────────────────────────────────────────
import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { getAccounts, type Account } from '../data/fakeApi';

export default function TheUseEffectWay() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    getAccounts()
      .then((d) => { if (alive) setAccounts(d); })
      .catch((e) => { if (alive) setError(String(e)); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, []);

  return (
    <div>
      <Link to="/" className="hint">← menu</Link>
      <h2 style={{ marginTop: 8 }}>Fetch in useEffect (the way you do it now)</h2>
      {loading && <p className="hint">Loading… (component already rendered, empty)</p>}
      {error && <p className="bad">{error}</p>}
      {!loading && accounts.map((a) => (
        <div key={a.id} style={{ padding: 6 }}><strong>{a.holder}</strong> · <span className="mono">{a.balance}</span></div>
      ))}
      <p className="note">
        Count what this needs: <strong>three</strong> state variables, a mount guard, and a loading
        branch. The sequence is render (empty) → effect fires → fetch → re-render (data). The spinner
        exists <strong>because the fetch starts AFTER the first render.</strong> Keep this on screen —
        demo 02 deletes almost all of it.
      </p>
    </div>
  );
}
