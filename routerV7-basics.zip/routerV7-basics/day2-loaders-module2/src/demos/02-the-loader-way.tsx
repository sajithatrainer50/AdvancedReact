// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · 02-the-loader-way.tsx
// │ ONE IDEA: a loader fetches BEFORE the component renders. The
// │           component has no loading state, no effect, no useState.
// └──────────────────────────────────────────────────────────────
import { useLoaderData, Link } from 'react-router';
import { getAccounts, type Account } from '../data/fakeApi';

// THE LOADER — lives in router.tsx as `loader: accountsLoader`. It runs while
// the route is being navigated to, BEFORE this component renders. The router
// waits for it, then renders the component with the data already available.
export async function accountsLoader(): Promise<Account[]> {
  return getAccounts();                     // just return the data (or a promise of it)
}

export default function TheLoaderWay() {
  // The data is ALREADY HERE. No loading branch, because the component never
  // renders until the loader resolved. useLoaderData gives you the return value.
  const accounts = useLoaderData() as Account[];

  return (
    <div>
      <Link to="/" className="hint">← menu</Link>
      <h2 style={{ marginTop: 8 }}>Loaded before render (the loader way)</h2>
      {accounts.map((a) => (
        <div key={a.id} style={{ padding: 6 }}><strong>{a.holder}</strong> · <span className="mono">{a.balance}</span></div>
      ))}
      <p className="note">
        No <code>useState</code>. No <code>useEffect</code>. No loading branch. The component is pure
        display, because by the time it renders the data is guaranteed to be there. Compare demo 01’s
        ~15 lines of orchestration with this one line: <code>const accounts = useLoaderData()</code>.
        The loading now happens during navigation, handled by the router — see demo 04.
      </p>
    </div>
  );
}
