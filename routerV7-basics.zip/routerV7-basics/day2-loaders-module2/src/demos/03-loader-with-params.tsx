// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · 03-loader-with-params.tsx
// │ ONE IDEA: the loader receives the route's :id (and search params).
// │           Fetch the RIGHT record before render, and a bad id throws
// │           straight to the error boundary — no loading/error state.
// └──────────────────────────────────────────────────────────────
import { useLoaderData, Link, type LoaderFunctionArgs } from 'react-router';
import { getAccount, type Account } from '../data/fakeApi';

// The loader is handed { params, request }. params.id is the :id from the URL.
// If getAccount throws its 404 Response, the router routes to ErrorBoundary —
// this component never renders in the error case. No try/catch here.
export async function accountLoader({ params }: LoaderFunctionArgs): Promise<Account> {
  return getAccount(params.id!);            // throws 404 for unknown ids
}

export default function LoaderWithParams() {
  const account = useLoaderData() as Account;
  return (
    <div>
      <Link to="/detail/acc_01" className="hint">acc_01</Link>{' · '}
      <Link to="/detail/acc_02" className="hint">acc_02</Link>{' · '}
      <Link to="/detail/acc_99" className="hint">acc_99 (404)</Link>
      <h2 style={{ marginTop: 8 }}>{account.holder}</h2>
      <p className="mono">{account.iban}</p>
      <strong className="n ok" style={{ fontSize: 30 }}>{account.balance}</strong>
      <p className="hint">{account.type} account</p>
      <p className="note">
        Click <strong>acc_99</strong>: the loader’s fetch 404s, throws, and the router shows the
        error page — this component is never even called. The happy path has zero error handling
        because errors are routed away. The loader gets <code>params.id</code> straight from the URL,
        so the right record is fetched <strong>before</strong> the page paints.
      </p>
    </div>
  );
}
