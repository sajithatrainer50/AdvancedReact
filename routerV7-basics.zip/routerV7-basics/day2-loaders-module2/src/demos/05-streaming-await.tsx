// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · 05-streaming-await.tsx
// │ ONE IDEA (the latest pattern): don't await slow data in the loader.
// │           Return the PROMISE, render the page instantly, and stream
// │           the slow part in with <Await> + Suspense.
// └──────────────────────────────────────────────────────────────
import { Suspense } from 'react';
import { useLoaderData, Await, Link, type LoaderFunctionArgs } from 'react-router';
import { getAccount, getTransactions, type Account, type Txn } from '../data/fakeApi';

type Loaded = { account: Account; transactions: Promise<Txn[]> };

// The KEY move: await the FAST data (account, 0.6s) so the page has its shell,
// but do NOT await the SLOW data (transactions, 1.8s) — return the promise.
// In React Router v7 you no longer need defer(); returning a promise is enough.
export async function streamingLoader({ params }: LoaderFunctionArgs): Promise<Loaded> {
  const account = await getAccount(params.id!);        // awaited: page waits for this
  const transactions = getTransactions(params.id!);    // NOT awaited: streams in later
  return { account, transactions };
}

export default function StreamingAwait() {
  const { account, transactions } = useLoaderData() as Loaded;

  return (
    <div>
      <Link to="/stream/acc_01" className="hint">acc_01</Link>{' · '}
      <Link to="/stream/acc_02" className="hint">acc_02</Link>
      {/* This part paints IMMEDIATELY — account was awaited in the loader. */}
      <h2 style={{ marginTop: 8 }}>{account.holder}</h2>
      <strong className="n ok" style={{ fontSize: 26 }}>{account.balance}</strong>

      <h3 style={{ marginTop: 16 }}>Recent transactions</h3>
      {/* This part streams in when the slow promise resolves, 1.8s later. */}
      <Suspense fallback={<p className="hint">loading transactions… (page already usable)</p>}>
        <Await resolve={transactions}>
          {(txns: Txn[]) => (
            <div>
              {txns.map((t) => (
                <div key={t.id} className="row" style={{ justifyContent: 'space-between', padding: '3px 0' }}>
                  <span>{t.merchant}</span>
                  <span className="mono">{t.amount} · {t.date}</span>
                </div>
              ))}
            </div>
          )}
        </Await>
      </Suspense>

      <p className="note">
        The header and balance appear at once; the transaction list streams in ~1.8s later without
        blocking the page. The loader <strong>awaited the fast data</strong> and{' '}
        <strong>returned the slow data as a promise</strong>. <code>&lt;Await&gt;</code> + Suspense
        renders the fallback until it resolves. This is the modern replacement for the old{' '}
        <code>defer()</code> helper — and it’s the same Suspense you learned yesterday, now driven by
        the router. Users get an instant, usable page instead of waiting for the slowest query.
      </p>
    </div>
  );
}
