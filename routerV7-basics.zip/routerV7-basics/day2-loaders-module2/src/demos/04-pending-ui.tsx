// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M2 · 04-pending-ui.tsx
// │ ONE IDEA: if the loader runs before render, where does the
// │           spinner go? Into useNavigation — a GLOBAL "is the router
// │           busy navigating?" signal, shown once, not per-component.
// └──────────────────────────────────────────────────────────────
import { useNavigation, Link, useLoaderData } from 'react-router';
import { getAccounts, type Account } from '../data/fakeApi';

export async function pendingLoader(): Promise<Account[]> {
  return getAccounts();                     // 600ms — long enough to see the pending bar
}

export default function PendingUI() {
  const accounts = useLoaderData() as Account[];
  const navigation = useNavigation();       // "idle" | "loading" | "submitting"
  const isNavigating = navigation.state === 'loading';

  return (
    <div>
      {/* This bar shows whenever ANY route is loading — one place, app-wide. */}
      {isNavigating && (
        <div style={{ background: '#185fa5', color: '#fff', padding: '6px 12px', borderRadius: 6, marginBottom: 12 }}>
          navigating… (the loader is running)
        </div>
      )}
      <Link to="/" className="hint">← menu</Link>{' · '}
      <Link to="/pending" className="hint">reload this route</Link>
      <h2 style={{ marginTop: 8 }}>Pending UI via useNavigation</h2>
      {accounts.map((a) => (
        <div key={a.id} style={{ padding: 6 }}><strong>{a.holder}</strong> · <span className="mono">{a.balance}</span></div>
      ))}
      <p className="note">
        The loader runs during navigation, so the component can’t own a loading flag — it doesn’t
        exist yet. Instead, <code>useNavigation().state</code> is a router-wide signal: it flips to{' '}
        <code>"loading"</code> the moment you navigate and back to <code>"idle"</code> when the loader
        settles. Click “reload this route” and watch the blue bar. One pending indicator for the whole
        app, not a spinner hand-wired into every page.
      </p>
    </div>
  );
}
