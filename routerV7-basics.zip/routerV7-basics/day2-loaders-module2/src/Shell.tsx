import { NavLink, Outlet, useNavigation } from 'react-router';

export function Shell() {
  const navigation = useNavigation();
  return (
    <div className="shell">
      <nav className="rail">
        <h1>NorthBridge</h1>
        <p>console · M2 loaders {navigation.state === 'loading' ? '· ⏳' : ''}</p>
        <NavLink to="/" end className={({ isActive }) => (isActive ? 'on' : '')}>Menu</NavLink>
        <NavLink to="/useeffect" className={({ isActive }) => (isActive ? 'on' : '')}>01 · useEffect way</NavLink>
        <NavLink to="/loader" className={({ isActive }) => (isActive ? 'on' : '')}>02 · loader way</NavLink>
        <NavLink to="/detail/acc_01" className={({ isActive }) => (isActive ? 'on' : '')}>03 · loader + params</NavLink>
        <NavLink to="/pending" className={({ isActive }) => (isActive ? 'on' : '')}>04 · pending UI</NavLink>
        <NavLink to="/stream/acc_01" className={({ isActive }) => (isActive ? 'on' : '')}>05 · streaming</NavLink>
      </nav>
      <main className="page"><Outlet /></main>
    </div>
  );
}
