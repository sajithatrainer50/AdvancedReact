import { createRoot } from 'react-dom/client';
import { RouterProvider } from 'react-router';
import { router } from './router';
import './index.css';

// The router is created ONCE, outside React, and handed to RouterProvider.
// Data Routers must not live in React state — see router.tsx for why.
createRoot(document.getElementById('root')!).render(<RouterProvider router={router} />);
