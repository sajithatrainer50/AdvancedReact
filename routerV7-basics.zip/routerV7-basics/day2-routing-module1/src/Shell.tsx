import { NavLink, Outlet } from 'react-router';

export function Shell() {
  return (
    <div className="shell">
      <nav className="rail">
        <h1>NorthBridge</h1>
        <p>console · M1 routing</p>
        <NavLink to="/" end className={({ isActive }) => (isActive ? 'on' : '')}>Accounts</NavLink>
        <NavLink to="/accounts/acc_01" className={({ isActive }) => (isActive ? 'on' : '')}>01 · Dynamic</NavLink>
        <NavLink to="/search" className={({ isActive }) => (isActive ? 'on' : '')}>02 · Search params</NavLink>
        <NavLink to="/nav" className={({ isActive }) => (isActive ? 'on' : '')}>03 · Programmatic</NavLink>
        <NavLink to="/broken/acc_99" className={({ isActive }) => (isActive ? 'on' : '')}>04 · Route error (404)</NavLink>
        <NavLink to="/does-not-exist" className={({ isActive }) => (isActive ? 'on' : '')}>04b · Catch-all 404</NavLink>
      </nav>
      <main className="page"><Outlet /></main>
    </div>
  );
}
