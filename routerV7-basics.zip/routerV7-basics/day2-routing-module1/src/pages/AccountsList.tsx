import { Link } from 'react-router';

export function AccountsList() {
  return (
    <div>
   
      <ol className="note" style={{ lineHeight: 2 }}>
        <li><Link to="/accounts/acc_01">01 Dynamic routing</Link> — params are strings; optional & splat segments</li>
        <li><Link to="/search">02 Search params</Link> — filters that survive refresh (the one that impresses)</li>
        <li><Link to="/nav">03 Programmatic navigation</Link> — useNavigate vs &lt;Link&gt;</li>
        <li><Link to="/broken/acc_99">04 Route error handling</Link> — a loader 404 routes to an error UI</li>
      </ol>
    </div>
  );
}
