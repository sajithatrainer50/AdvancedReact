export type Account = { id: string; holder: string; iban: string; balance: string; type: string };

export const ACCOUNTS: Account[] = [
  { id: 'acc_01', holder: 'Aoife Byrne',   iban: 'IE29 AIBK …78', balance: '€4,182.66',  type: 'Operating' },
  { id: 'acc_02', holder: 'Bob Callaghan', iban: 'IE64 IRCE …78', balance: '€11,904.10', type: 'Savings' },
  { id: 'acc_03', holder: 'Ciara Doyle',   iban: 'IE12 BOFI …78', balance: '€712.44',    type: 'Current' },
];
