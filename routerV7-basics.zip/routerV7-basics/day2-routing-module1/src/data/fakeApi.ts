
// The data is hardcoded, but the SHAPE is
// identical to a real endpoint. Each function returns a Promise, takes time,
// and can reject. 


export type Account = {
  id: string; holder: string; iban: string; balance: string; type: string;
};

const DB: Account[] = [
  { id: 'acc_01', holder: 'Aoife Byrne',   iban: 'IE29 AIBK …78', balance: '€4,182.66',  type: 'Operating' },
  { id: 'acc_02', holder: 'Bob Callaghan', iban: 'IE64 IRCE …78', balance: '€11,904.10', type: 'Savings' },
  { id: 'acc_03', holder: 'Ciara Doyle',   iban: 'IE12 BOFI …78', balance: '€712.44',    type: 'Current' },
];

// Simulates network latency so loading states are visible and real.
const NETWORK_DELAY = 600;
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

// GET /accounts
export async function getAccounts(): Promise<Account[]> {
  await wait(NETWORK_DELAY);
  // REAL: return fetch('/api/accounts').then(r => r.json());
  return DB;
}

// GET /accounts/:id  — rejects on a missing id, exactly like a 404 would.
export async function getAccount(id: string): Promise<Account> {
  await wait(NETWORK_DELAY);
  // REAL: const r = await fetch(`/api/accounts/${id}`);
  //       if (!r.ok) throw new Response('Not found', { status: 404 });
  //       return r.json();
  const account = DB.find((a) => a.id === id);
  if (!account) throw new Response(`Account ${id} not found`, { status: 404 });
  return account;
}
