// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M1 · router.tsx
// │ Wires the four routing-gap demos into one route tree.
// └──────────────────────────────────────────────────────────────
import { createBrowserRouter, redirect } from 'react-router';
import { Shell } from './Shell';
import { AccountsList } from './pages/AccountsList';
import DynamicRouting from './demos/01-dynamic-routing';
import SearchParamsArchitecture from './demos/02-search-params';
import ProgrammaticNav from './demos/03-programmatic-nav';
import RouteErrorHandling, { BrokenOnPurpose } from './demos/04-route-error-handling';
import { getAccount } from './data/fakeApi';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Shell,
    // A route-level error boundary. Anything thrown by a child route's loader
    // or component that isn't caught closer bubbles up to here.
    ErrorBoundary: RouteErrorHandling,
    children: [
      { index: true, Component: AccountsList },

      // DYNAMIC — required :id, plus an OPTIONAL :tab segment.
      { path: 'accounts/:id', Component: DynamicRouting },
      { path: 'accounts/:id/:tab', Component: DynamicRouting },

      // SEARCH PARAMS demo.
      { path: 'search', Component: SearchParamsArchitecture },

      // PROGRAMMATIC NAV demo.
      { path: 'nav', Component: ProgrammaticNav },

      // ROUTE ERROR — this loader calls the fake API, which throws a 404
      // Response for unknown ids. That thrown Response routes to ErrorBoundary.
      {
        path: 'broken/:id',
        Component: BrokenOnPurpose,
        loader: async ({ params }) => {
          await getAccount(params.id!);   // throws 404 for acc_99 -> ErrorBoundary
          return null;
        },
      },

      // A redirect example — /home just bounces to "/".
      { path: 'home', loader: () => redirect('/') },

      // SPLAT / catch-all — any unmatched URL lands here. Throwing a Response
      // sends it to the ErrorBoundary as a clean 404 instead of a blank screen.
      {
        path: '*',
        loader: () => { throw new Response('No such page', { status: 404, statusText: 'Not Found' }); },
      },
    ],
  },
]);
