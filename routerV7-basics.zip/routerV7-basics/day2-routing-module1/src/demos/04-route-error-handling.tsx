// ┌──────────────────────────────────────────────────────────────
// │ Day 2 · M1 · 04-route-error-handling.tsx
// │ ONE IDEA: a route can declare its OWN error UI. When a loader or
// │           component throws, the router shows that UI in place —
// │           the rest of the app (the Shell) stays alive.
// └──────────────────────────────────────────────────────────────
import { useRouteError, isRouteErrorResponse, Link, useNavigate } from 'react-router';

// This component is wired as the route's `ErrorBoundary` in router.tsx.
// The router renders it INSTEAD of the route's Component when something throws.
export default function RouteErrorHandling() {
  const error = useRouteError();          // the router hands you whatever was thrown
  const navigate = useNavigate();

  // A thrown Response (like our fake API's 404) is a "route error response".
  // isRouteErrorResponse lets you branch on the HTTP-style status.
  if (isRouteErrorResponse(error)) {
    return (
      <div className="card" style={{ borderColor: '#c2410c' }}>
        <strong className="bad" style={{ fontSize: 18 }}>
          {error.status} — {error.statusText || 'Not found'}
        </strong>
        <p className="hint">{String(error.data)}</p>
        <div className="row" style={{ marginTop: 10 }}>
          <Link to="/">back to accounts</Link>
          <button className="ghost" onClick={() => navigate(-1)}>go back</button>
        </div>
      </div>
    );
  }

  // Any other thrown Error.
  const message = error instanceof Error ? error.message : 'Unknown error';
  return (
    <div className="card" style={{ borderColor: '#c2410c' }}>
      <strong className="bad">Something went wrong</strong>
      <p className="hint mono">{message}</p>
      <Link to="/">back to accounts</Link>
    </div>
  );
}

// A tiny page whose loader deliberately throws, to trigger the boundary above.
// (Its loader lives in router.tsx.) Visiting /accounts/acc_99 hits our fake
// API's 404 and routes here automatically.
export function BrokenOnPurpose() {
  return <p>You should never see this — the loader throws before it renders.</p>;
}
