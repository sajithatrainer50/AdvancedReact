
// Day 2  M1 03-programmatic-nav.tsx
// ONE IDEA: <Link> is for the user clicking. useNavigate is for
// YOUR code deciding to move — after a save, a guard, a timeout.

import { useNavigate, Link } from 'react-router';
import { useState } from 'react';

export default function ProgrammaticNav() {
  const navigate = useNavigate();
  const [status, setStatus] = useState('idle');

  // Navigate AFTER an async action completes — the classic "save then redirect".
  async function saveThenGo() {
    setStatus('saving…');
    await new Promise((r) => setTimeout(r, 800));
    setStatus('saved — redirecting');
    navigate('/accounts/acc_02');           // programmatic: code moves the user
  }

  return (
    <div>
      <Link to="/" className="hint">← accounts</Link>
      <h2 style={{ marginTop: 8 }}>Programmatic navigation</h2>

      <div className="card" style={{ marginTop: 12 }}>
        <div className="row" style={{ gap: 10, flexWrap: 'wrap' }}>
          <button onClick={saveThenGo}>save, then redirect</button>
          <button className="ghost" onClick={() => navigate(-1)}>go back (navigate(-1))</button>
          <button className="ghost" onClick={() => navigate('/search?type=Savings')}>
            go to a filtered URL
          </button>
          <button className="ghost" onClick={() => navigate('/accounts/acc_01', { replace: true })}>
            replace (no back-button entry)
          </button>
        </div>
        <p className="hint" style={{ marginTop: 10 }}>status: {status}</p>
      </div>

      <p className="note">
        Four patterns you’ll reach for: <strong>navigate(path)</strong> after an event (save →
        redirect); <strong>navigate(-1)</strong> to go back like the browser button;{' '}
        <strong>navigate(path)</strong> to jump to a URL with search params baked in; and{' '}
        <strong>{'{ replace: true }'}</strong> to swap the current history entry instead of pushing
        a new one — used after login so “back” doesn’t return to the login page. The rule:{' '}
        <strong>&lt;Link&gt; for the user’s intent, useNavigate for your code’s decisions.</strong>
      </p>
    </div>
  );
}
