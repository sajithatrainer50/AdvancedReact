
// Day 2 · M1 · 02-search-params.tsx
// ONE IDEA: put filter/sort state in the URL, not useState. Then it
// survives refresh, is shareable, and works with back/forward.

import { useSearchParams, Link } from 'react-router';
import { ACCOUNTS } from '../data/accounts';

export default function SearchParamsArchitecture() {
  // useSearchParams is like useState — but the "state" lives in the URL's ?query.
  const [searchParams, setSearchParams] = useSearchParams();

  // Read current filter/sort straight from the URL. Defaults when absent.
  const type = searchParams.get('type') ?? 'all';
  const sort = searchParams.get('sort') ?? 'holder';

  // Derive the visible list from the URL state. No useState anywhere.
  const filtered = ACCOUNTS
    .filter((a) => type === 'all' || a.type === type)
    .sort((a, b) => (sort === 'holder' ? a.holder.localeCompare(b.holder) : a.balance.localeCompare(b.balance)));

  // Writing a param updates the URL, which re-renders this component.
  function setParam(key: string, value: string) {
    const next = new URLSearchParams(searchParams);
    if (value === 'all') next.delete(key);
    else next.set(key, value);
    setSearchParams(next);
  }

  return (
    <div>
      <Link to="/" className="hint">← accounts</Link>
      <h2 style={{ marginTop: 8 }}>Filters live in the URL</h2>

      <div className="row" style={{ gap: 16, marginTop: 12 }}>
        <label><span className="lbl">type</span>
          <select value={type} onChange={(e) => setParam('type', e.target.value)}>
            <option value="all">all</option><option>Operating</option>
            <option>Savings</option><option>Current</option>
          </select>
        </label>
        <label><span className="lbl">sort</span>
          <select value={sort} onChange={(e) => setParam('sort', e.target.value)}>
            <option value="holder">holder</option><option value="balance">balance</option>
          </select>
        </label>
      </div>

      <p className="mono hint" style={{ marginTop: 10 }}>current URL: /search?{searchParams.toString() || '(empty)'}</p>

      <div style={{ marginTop: 8 }}>
        {filtered.map((a) => (
          <div key={a.id} style={{ padding: 6 }}>
            <strong>{a.holder}</strong> · {a.type} · <span className="mono">{a.balance}</span>
          </div>
        ))}
      </div>

      <p className="note">
        Change the dropdowns and watch the URL. Now the payoff — <strong>refresh the page.</strong>{' '}
        The filters survive, because they were never in component state; they’re in the URL. Copy the
        URL to another tab: same filtered view. This is “search params as the source of truth” — the
        URL becomes shareable, bookmarkable, back-button-aware application state, for free.
      </p>
    </div>
  );
}
