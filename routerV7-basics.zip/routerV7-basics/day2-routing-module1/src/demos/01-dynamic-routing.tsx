
// Day 2 · M1 · 01-dynamic-routing.tsx
// A URL param is ALWAYS a string, and there are three kinds of dynamic segment, not one.

// The routes that reach this file (declared in router.tsx):
//   accounts/:id            -> required param      -> params.id
//   accounts/:id/:tab?      -> OPTIONAL param      -> params.tab may be undefined
//   files/*                 -> splat / catch-all   -> params['*'] = the whole rest
//
// This component is hit by the first two. Demo 04 handles the splat + 404.

import { useParams, Link } from 'react-router';

export default function DynamicRouting() {
  const params = useParams();

  // The trap: params.id is a STRING. Always. "acc_01" is fine, but if your
  // route were /orders/:orderId and you did params.orderId > 100, that's a
  // string comparison, not a number one. Coerce explicitly.
  const idAsString = params.id ?? '(none)';

  return (
    <div>
      <Link to="/" className="hint">← accounts</Link>
      <h2 style={{ marginTop: 8 }}>Dynamic segments</h2>

      <div className="card" style={{ marginTop: 12 }}>
        <span className="lbl">params.id (required) — note the quotes: it is a string</span>
        <strong className="mono ok" style={{ fontSize: 18 }}>"{idAsString}"</strong>

        <span className="lbl" style={{ marginTop: 12 }}>params.tab (optional) — undefined when absent</span>
        <strong className="mono" style={{ fontSize: 18 }}>{JSON.stringify(params.tab)}</strong>

        <div className="row" style={{ marginTop: 14, gap: 8, flexWrap: 'wrap' }}>
          <Link to="/accounts/acc_01">/accounts/acc_01</Link>
          <Link to="/accounts/acc_01/transactions">…/acc_01/transactions</Link>
          <Link to="/accounts/acc_02/statements">…/acc_02/statements</Link>
        </div>
      </div>

      <p className="note">
        Click the links and watch <code>params.tab</code> flip between a string and{' '}
        <code>undefined</code>
        <strong>(1)</strong> every param is a <strong>string</strong> — coerce with{' '}
        <code>Number(params.id)</code> if you need a number; <strong>(2)</strong> an{' '}
        <strong>optional</strong> segment is written <code>:tab?</code> and its param is{' '}
        <code>undefined</code> when the URL omits it. There is also a third kind — the{' '}
        <strong>splat</strong> <code>*</code> for catch-all — which we use for 404s in demo 04.
      </p>
    </div>
  );
}
