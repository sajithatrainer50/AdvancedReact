// ┌──────────────────────────────────────────────────────────────
// │ Router+Query · lib/api.ts — fake API with a network counter
// └──────────────────────────────────────────────────────────────
export type Account = { id: string; holder: string; balance: number };

const DB: Record<string, Account> = {
  acc_01: { id: 'acc_01', holder: 'Aoife Byrne',   balance: 4182 },
  acc_02: { id: 'acc_02', holder: 'Bob Callaghan', balance: 11904 },
  acc_03: { id: 'acc_03', holder: 'Ciara Doyle',   balance: 712 },
};

export const netCalls = { count: 0 };
const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function fetchAccount(id: string): Promise<Account> {
  netCalls.count++;
  console.log(`%c NETWORK %c fetchAccount(${id}) #${netCalls.count}`,
    'background:#854F0B;color:#fff;padding:1px 5px;border-radius:3px', '');
  await wait(700);
  const a = DB[id];
  if (!a) throw new Response('Not found', { status: 404 });
  return a;
}

export async function deposit(id: string, amount: number): Promise<Account> {
  await wait(600);
  DB[id] = { ...DB[id], balance: DB[id].balance + amount };
  return DB[id];
}
