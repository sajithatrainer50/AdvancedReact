import { Link } from 'react-router';
export function Menu() {
  return (
    <div>
      <h2>Module — code splitting</h2>
      <p className="hint">Open DevTools → Network → filter JS before you click around.</p>
      <ol className="note" style={{ lineHeight: 2 }}>
        <li><Link to="/eager">01 Eager route</Link> — heavy dep in the main bundle (the problem)</li>
        <li><Link to="/lazy">02 Lazy route</Link> — router `lazy`, separate chunk on demand (recommended)</li>
        <li><Link to="/react-lazy">03 React.lazy</Link> — split any component, not just routes</li>
      </ol>
      <p className="note">
        To see the split concretely: run <code>npm run build</code> and read the output — you’ll see
        one chunk per lazy route. Or watch the Network tab as you navigate.
      </p>
    </div>
  );
}
