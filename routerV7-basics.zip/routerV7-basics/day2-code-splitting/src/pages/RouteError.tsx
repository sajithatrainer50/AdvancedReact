import { useRouteError, isRouteErrorResponse, Link } from 'react-router';
export default function RouteError() {
  const error = useRouteError();
  const msg = isRouteErrorResponse(error) ? `${error.status} ${error.statusText}` :
              error instanceof Error ? error.message : 'Unknown';
  return (
    <div className="card" style={{ borderColor: '#c2410c' }}>
      <strong className="bad">{msg}</strong><br /><Link to="/">back to menu</Link>
    </div>
  );
}
