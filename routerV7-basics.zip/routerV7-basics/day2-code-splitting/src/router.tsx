// ┌──────────────────────────────────────────────────────────────
// │ Code Splitting · router.tsx
// │ Three routes: one eager (in main bundle), one lazy via route.lazy,
// │ one using React.lazy inside the component.
// └──────────────────────────────────────────────────────────────
import { createBrowserRouter } from 'react-router';
import React from "react";
import { Shell } from './Shell';
import { Menu } from './pages/Menu';
import RouteError from './pages/RouteError';

// EAGER: statically imported -> lands in the main bundle.
import EagerRoute from './demos/01-eager-route';
// REACT.LAZY demo is itself a normal component; the splitting happens INSIDE it.
import ReactLazyDemo from './demos/03-react-lazy';
const LazyComponent = React.lazy(()=> './demos/02-lazy-module')
export const router = createBrowserRouter([
  {
    path: '/',
    Component: Shell,
    ErrorBoundary: RouteError,
    children: [
      { index: true, Component: Menu },

      // Eagerly imported — part of the main chunk.
      { path: 'eager', Component: EagerRoute },

      // LAZY via React Router v7's `lazy` property. The function returns a
      // module with a `Component` export (and optionally loader/action). Vite
      // splits this file + its imports (heavyLib) into a separate chunk that
      // downloads only when this route is visited.
      { path: 'lazy', Component: LazyComponent },

      // Uses React.lazy INSIDE the component (splitting is in the component).
      { path: 'react-lazy', Component: ReactLazyDemo },
    ],
  },
]);
