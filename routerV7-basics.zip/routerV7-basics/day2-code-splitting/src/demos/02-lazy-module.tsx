// ┌──────────────────────────────────────────────────────────────
// │ Code Splitting · 02-lazy-module.tsx
// │ This file is loaded ON DEMAND by the router's `lazy` property.
// │ It exports Component (and could export loader/action/ErrorBoundary).
// │ Vite puts everything this file imports into a SEPARATE chunk.
// └──────────────────────────────────────────────────────────────
import { Link } from 'react-router';
import { renderBigReport } from './heavyLib';   // heavy dep — now in the LAZY chunk

// Named export `Component` is what React Router v7's `lazy` looks for.
export default function Component() {
  return (
    <div>
      <Link to="/" className="hint">← menu</Link>
      <h2 style={{ marginTop: 8 }}>Lazy route (loaded on demand)</h2>
      <pre style={{ maxHeight: 180, overflow: 'auto', fontSize: 11 }}>{renderBigReport()}</pre>
      <p className="note">
        Same heavy dependency — but this file is only imported when you navigate here, via the
        router’s <code>lazy</code> property. Open DevTools → Network, filter JS, and click this route
        from the menu: you’ll see a NEW chunk download at that moment. Users who never visit never
        pay for it. This is route-level code splitting.
      </p>
    </div>
  );
}
