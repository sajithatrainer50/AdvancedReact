// ┌──────────────────────────────────────────────────────────────
// │ Code Splitting · demos/heavyLib.ts
// │ A stand-in for a genuinely heavy dependency (a chart lib, a PDF
// │ generator, a date library). We pad it so its chunk is visibly
// │ separate in the Network tab and the build output.
// └──────────────────────────────────────────────────────────────
// Imagine this is 200KB of charting code. The point: a route that uses it
// should NOT force every other route to download it.
export function renderBigReport(): string {
  const rows = Array.from({ length: 50 }, (_, i) => `Row ${i}: €${(i * 137.5).toFixed(2)}`);
  return rows.join('\n');
}
// Padding to make the chunk visibly non-trivial in the build output.
export const FILLER = Array.from({ length: 500 }, (_, i) => `constant_${i}_${'x'.repeat(40)}`);
