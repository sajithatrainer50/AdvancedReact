// ┌──────────────────────────────────────────────────────────────
// │ Code Splitting · 01-eager-route.tsx
// │ ONE IDEA: an eagerly-imported route ships in the MAIN bundle —
// │           every user downloads it even if they never visit it.
// └──────────────────────────────────────────────────────────────
import { Link } from 'react-router';
import { renderBigReport } from './heavyLib';   // <- imported eagerly, top of file

export default function EagerRoute() {
  return (
    <div>
      <Link to="/" className="hint">← menu</Link>
      <h2 style={{ marginTop: 8 }}>Eager route (heavy dep in the main bundle)</h2>
      <pre style={{ maxHeight: 180, overflow: 'auto', fontSize: 11 }}>{renderBigReport()}</pre>
      <p className="note">
        This route statically imports <code>heavyLib</code> at the top of the file. Because
        <code>router.tsx</code> also imports THIS component statically, the heavy code lands in the
        <strong> main bundle</strong> — downloaded by every user on first load, even those who never
        open this page. Run <code>npm run build</code> and you’ll see it inside the main chunk.
      </p>
    </div>
  );
}
