import { renderBigReport } from './heavyLib';
export default function HeavyPanel() {
  return <pre style={{ maxHeight: 160, overflow: 'auto', fontSize: 11 }}>{renderBigReport()}</pre>;
}
