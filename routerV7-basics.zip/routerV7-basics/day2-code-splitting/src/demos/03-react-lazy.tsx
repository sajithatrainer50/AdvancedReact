// ┌──────────────────────────────────────────────────────────────
// │ Code Splitting · 03-react-lazy.tsx
// │ ONE IDEA: React.lazy + Suspense is the component-level splitting
// │           you already know. Works for ANY component, not just routes.
// └──────────────────────────────────────────────────────────────
import { lazy, Suspense, useState } from 'react';
import { Link } from 'react-router';

// The heavy panel is only fetched when `show` first becomes true.
const HeavyPanel = lazy(() => import('./heavyPanel'));

export default function ReactLazyDemo() {
  const [show, setShow] = useState(false);
  return (
    <div>
      <Link to="/" className="hint">← menu</Link>
      <h2 style={{ marginTop: 8 }}>React.lazy — split any component, not just routes</h2>
      <button onClick={() => setShow(true)} disabled={show}>load the heavy panel</button>
      <div style={{ marginTop: 12 }}>
        {show && (
          <Suspense fallback={<p className="hint">downloading panel chunk…</p>}>
            <HeavyPanel />
          </Suspense>
        )}
      </div>
      <p className="note">
        <code>React.lazy(() =&gt; import(...))</code> wrapped in <code>&lt;Suspense&gt;</code> is the
        component-level version — use it for a heavy modal, a chart, a rich editor that isn’t needed
        on first paint. Click the button with the Network tab open: the chunk downloads only then.
        The router’s <code>lazy</code> (demo 02) is the route-level equivalent; this is for anything
        inside a page.
      </p>
    </div>
  );
}
