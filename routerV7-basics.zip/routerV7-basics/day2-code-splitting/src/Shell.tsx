import { NavLink, Outlet, useNavigation } from 'react-router';
export function Shell() {
  const nav = useNavigation();
  return (
    <div className="shell">
      <nav className="rail">
        <h1>NorthBridge</h1>
        <p>code splitting {nav.state === 'loading' ? '· ⏳' : ''}</p>
        <NavLink to="/" end className={({ isActive }) => (isActive ? 'on' : '')}>Menu</NavLink>
        <NavLink to="/eager" className={({ isActive }) => (isActive ? 'on' : '')}>01 · eager</NavLink>
        <NavLink to="/lazy" className={({ isActive }) => (isActive ? 'on' : '')}>02 · lazy route</NavLink>
        <NavLink to="/react-lazy" className={({ isActive }) => (isActive ? 'on' : '')}>03 · React.lazy</NavLink>
      </nav>
      <main className="page"><Outlet /></main>
    </div>
  );
}
