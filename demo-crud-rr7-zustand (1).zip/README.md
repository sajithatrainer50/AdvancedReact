# Posts CRUD Demo

A small, five-page CRUD app: React Router v7 (data loading) + Zustand, talking
to the free [JSONPlaceholder](https://jsonplaceholder.typicode.com) API.

## Run it

```bash
npm install
npm run dev
```

Then open the printed local URL (usually http://localhost:5173).

## Read this next

See **GUIDE.md** for a page-by-page walkthrough of how the GET / GET-by-id /
POST / PUT / DELETE flows are wired up, and why the project is structured
the way it is.
