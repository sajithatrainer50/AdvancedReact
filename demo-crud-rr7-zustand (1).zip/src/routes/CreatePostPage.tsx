import {
  Form,
  redirect,
  useActionData,
  useNavigation,
  type ActionFunctionArgs,
} from "react-router";
import { createPost } from "../api/postsApi";
import { usePostStore } from "../store/postStore";

type ActionResult = { error: string } | undefined;

// A ROUTE ACTION. React Router calls this when a <Form> targeting this
// route is submitted — you never call it directly either.
//
// Two very different failure modes here, handled two different ways:
//  - bad input (empty title) → we RETURN a plain object. That goes to
//    useActionData() below, so the page can show it next to the form.
//  - a real failure (network, API down) → createPost/assertOk THROWS a
//    Response, which skips this page entirely and goes to the nearest
//    error boundary. Validation problems and system failures are not
//    the same kind of error, so they don't go to the same place.
export async function createAction({
  request,
}: ActionFunctionArgs): Promise<ActionResult | Response> {
  const formData = await request.formData();
  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();

  if (!title || !body) {
    return { error: "Title and body are both required." };
  }

  // Reminder: JSONPlaceholder always answers this with a fake
  // { id: 101, ... } and doesn't actually save it. We still make the
  // real request (so you can see the real request/response in dev
  // tools) — but we trust OUR copy of the result, held in Zustand,
  // to make the new post actually show up in the list.
  const created = await createPost({ title, body });
  usePostStore.getState().upsertPost(created);

  return redirect("/");
}

export default function CreatePostPage() {
  const actionData = useActionData() as ActionResult;
  const navigation = useNavigation();
  // True only while THIS form's submission is in flight.
  const isSubmitting = navigation.formAction === "/posts/new";

  return (
    <section>
      <div className="page-heading">
        <h1>New post</h1>
        <span className="pill">POST /posts</span>
      </div>

      <Form method="post" className="post-form">
        <label>
          Title
          <input type="text" name="title" required />
        </label>

        <label>
          Body
          <textarea name="body" rows={5} required />
        </label>

        {actionData?.error && <p className="form-error">{actionData.error}</p>}

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Creating…" : "Create post"}
        </button>
      </Form>
    </section>
  );
}
