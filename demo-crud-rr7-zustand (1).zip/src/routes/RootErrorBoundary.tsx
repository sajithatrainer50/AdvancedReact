import { isRouteErrorResponse, Link, useRouteError } from "react-router";

// In React Router v6 you'd write a class component and export it as
// `errorElement`. In v7 a route can just export an `ErrorBoundary`
// component, and pull the error out with useRouteError() — no class,
// no componentDidCatch.
//
// This one sits on the root route, so it's the last line of defence:
// it catches anything a page-level boundary didn't handle (a network
// timeout, a bug in a component, JSONPlaceholder being down, etc).
export default function RootErrorBoundary() {
  const error = useRouteError();

  // isRouteErrorResponse is true only when something did
  // `throw new Response(...)` (see assertOk in postsApi.ts).
  // That gives us a real HTTP status to show.
  if (isRouteErrorResponse(error)) {
    return (
      <div className="error-panel">
        <h1>
          {error.status} {error.statusText}
        </h1>
        <p>The API didn't return what we expected.</p>
        <Link to="/">Back to all posts</Link>
      </div>
    );
  }

  // Anything else — a thrown Error, a network failure, a bug.
  const message = error instanceof Error ? error.message : "Unknown error";
  return (
    <div className="error-panel">
      <h1>Something went wrong</h1>
      <p>{message}</p>
      <Link to="/">Back to all posts</Link>
    </div>
  );
}
