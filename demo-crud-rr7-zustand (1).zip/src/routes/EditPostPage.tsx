import { startTransition, useOptimistic } from "react";
import {
  Form,
  redirect,
  useActionData,
  useNavigation,
  useParams,
  type ActionFunctionArgs,
} from "react-router";
import { updatePost } from "../api/postsApi";
import { usePostStore } from "../store/postStore";

type ActionResult = { error: string } | undefined;

// The loader for this route is postDetailLoader, reused as-is from
// PostDetailPage.tsx — an edit page needs the same "fetch one post"
// work a detail page needs, so there's no reason to write it twice.
// See router.tsx for where it's wired up.

// PUT /posts/:id
export async function updateAction({
  params,
  request,
}: ActionFunctionArgs): Promise<ActionResult | Response> {
  const id = Number(params.id);
  const formData = await request.formData();
  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();

  if (!title || !body) {
    return { error: "Title and body are both required." };
  }

  // Same JSONPlaceholder quirk as create: the PUT "succeeds" but the
  // server keeps serving the old data on the next GET. upsertPost is
  // what makes the edit actually stick, from the app's point of view.
  const updated = await updatePost(id, { title, body });
  usePostStore.getState().upsertPost(updated);

  return redirect(`/posts/${id}`);
}

export default function EditPostPage() {
  const { id } = useParams();
  const post = usePostStore((state) =>
    state.posts.find((p) => p.id === Number(id))
  );
  const actionData = useActionData() as ActionResult;
  const navigation = useNavigation();
  const isSubmitting = navigation.formAction === `/posts/${id}/edit`;

  // useOptimistic (new in React 19): lets us show the edited text
  // straight away, while the PUT request is still in flight. If you
  // never touch the form, optimisticPost === post. The moment you
  // submit, it flips to your in-progress edit; once the real action
  // finishes (redirect to the detail page), this component unmounts,
  // so there's nothing to "roll back" — but if the action had failed,
  // React would automatically drop the optimistic value on its own.
  const [optimisticPost, setOptimisticPost] = useOptimistic(
    post,
    (current, next: { title: string; body: string }) =>
      current ? { ...current, ...next } : current
  );

  if (!post || !optimisticPost) return null;

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    const formData = new FormData(event.currentTarget);
    const next = {
      title: String(formData.get("title") ?? ""),
      body: String(formData.get("body") ?? ""),
    };
    // Optimistic updates must happen inside a transition — this is
    // what tells React "this is a low-priority UI update, feel free
    // to keep showing the old value until you're ready". We wrap it
    // ourselves rather than relying on the Form's internal one, so
    // it's explicit and doesn't depend on React Router's internals.
    startTransition(() => setOptimisticPost(next));
    // No event.preventDefault() here — the Form component below
    // still needs to see this submit event and send it to updateAction.
  }

  return (
    <section>
      <div className="page-heading">
        <h1>Edit post</h1>
        <span className="pill">PUT /posts/{post.id}</span>
      </div>

      <div className="edit-layout">
        <Form method="post" className="post-form" onSubmit={handleSubmit}>
          <label>
            Title
            <input type="text" name="title" defaultValue={post.title} required />
          </label>

          <label>
            Body
            <textarea name="body" rows={5} defaultValue={post.body} required />
          </label>

          {actionData?.error && (
            <p className="form-error">{actionData.error}</p>
          )}

          <button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving…" : "Save changes"}
          </button>
        </Form>

        {/* Live preview, driven by the optimistic value. Try slowing
            your network in devtools — you'll see this update instantly
            on submit, well before the "Saving…" button resolves. */}
        <aside className="preview-card">
          <p className="preview-label">Live preview</p>
          <h3>{optimisticPost.title}</h3>
          <p>{optimisticPost.body}</p>
        </aside>
      </div>
    </section>
  );
}
