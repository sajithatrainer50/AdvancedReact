import { Link, useParams, type LoaderFunctionArgs } from "react-router";
import { getPostById } from "../api/postsApi";
import { usePostStore } from "../store/postStore";

// React Router passes the dynamic URL segment (":id") in as
// params.id — always a string, since it comes straight off the URL.
// We convert it and sanity-check it BEFORE calling the API, so a
// silly URL like /posts/abc fails fast with a clear error, instead
// of turning into a confusing network error.
//
// This loader is reused by three routes: the detail page, the edit
// page, and the delete-confirm page (see router.tsx) — all three need
// "the current post for this id" before they can render.
export async function postDetailLoader({ params }: LoaderFunctionArgs) {
  const id = Number(params.id);
  if (Number.isNaN(id)) {
    throw new Response("That's not a valid post id", { status: 400 });
  }

  // Same reasoning as the list loader: if we already have this post
  // (e.g. you just edited it and got redirected back here), trust
  // that copy instead of re-fetching — a re-fetch would hand back
  // JSONPlaceholder's original, never-actually-updated data and make
  // your edit look like it silently failed.
  const cached = usePostStore.getState().posts.find((p) => p.id === id);
  if (cached) {
    return cached;
  }

  // getPostById throws a Response itself if the API says 404
  // (see assertOk in postsApi.ts) — that throw is what triggers
  // PostNotFoundBoundary for this route branch.
  const post = await getPostById(id);
  usePostStore.getState().upsertPost(post);
  return post;
}

export default function PostDetailPage() {
  const { id } = useParams();

  // Same pattern as the list page: read from the store, not
  // useLoaderData(). By the time this component renders, the loader
  // above has already finished and already called upsertPost — so
  // this lookup always finds the post on the very first render.
  const post = usePostStore((state) =>
    state.posts.find((p) => p.id === Number(id))
  );

  // Defensive only — the loader guarantees `post` exists before this
  // component ever mounts (or it would have thrown, and
  // PostNotFoundBoundary would be showing instead of this component).
  if (!post) return null;

  return (
    <section>
      <div className="page-heading">
        <h1>{post.title}</h1>
        <span className="pill">GET /posts/{post.id}</span>
      </div>

      <p className="post-body">{post.body}</p>

      <div className="post-actions">
        <Link to={`/posts/${post.id}/edit`}>Edit this post</Link>
        <Link to={`/posts/${post.id}/delete`} className="danger">
          Delete this post
        </Link>
        <Link to="/">Back to all posts</Link>
      </div>
    </section>
  );
}
