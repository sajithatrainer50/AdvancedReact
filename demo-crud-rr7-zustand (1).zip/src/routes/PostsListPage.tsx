import { Link } from "react-router";
import { getAllPosts } from "../api/postsApi";
import { usePostStore } from "../store/postStore";

// A ROUTE LOADER. React Router calls this itself, before the page
// renders, every time you navigate to "/". You never call it by hand.
//
// IMPORTANT: it checks the store first. Every create/edit/delete on
// this project redirects back to "/" when it's done — if this loader
// blindly re-fetched every time, it would immediately overwrite those
// changes with JSONPlaceholder's original (unmodified) data, because
// the fake API never actually saves a write. So: fetch once per
// session, then trust the store, the same way you'd trust a cache.
export async function listLoader() {
  const { posts, listLoaded } = usePostStore.getState();
  if (listLoaded) {
    return posts;
  }

  const fetched = await getAllPosts();
  usePostStore.getState().setPosts(fetched);
  return fetched;
}

export default function PostsListPage() {
  // Reading from the STORE, not from useLoaderData(). This is what
  // makes the list update itself the moment you create, edit or
  // delete a post on another page — no refetch needed, because that
  // page already called upsertPost / removePost on the same store.
  const posts = usePostStore((state) => state.posts);

  return (
    <section>
      <div className="page-heading">
        <h1>All posts</h1>
        <span className="pill">GET /posts</span>
      </div>

      {posts.length === 0 ? (
        <p className="empty-state">No posts yet.</p>
      ) : (
        <ul className="post-list">
          {posts.map((post) => (
            <li key={post.id} className="post-list-item">
              <Link to={`/posts/${post.id}`} className="post-title">
                {post.title}
              </Link>
              <div className="post-actions">
                <Link to={`/posts/${post.id}/edit`}>Edit</Link>
                <Link to={`/posts/${post.id}/delete`} className="danger">
                  Delete
                </Link>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
