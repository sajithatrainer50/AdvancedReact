import {
  Form,
  Link,
  redirect,
  useNavigation,
  useParams,
  type ActionFunctionArgs,
} from "react-router";
import { deletePost } from "../api/postsApi";
import { usePostStore } from "../store/postStore";

// The loader for this route is postDetailLoader too (see router.tsx) —
// we need the post's title/body to show a "you're about to delete
// this" preview before committing to it.

// DELETE /posts/:id
export async function deleteAction({ params }: ActionFunctionArgs) {
  const id = Number(params.id);

  // JSONPlaceholder answers DELETE with 200 and an empty body, but
  // (like create and update) doesn't actually remove anything server
  // side. removePost is what makes it disappear from the app.
  await deletePost(id);
  usePostStore.getState().removePost(id);

  return redirect("/");
}

export default function DeletePostPage() {
  const { id } = useParams();
  const post = usePostStore((state) =>
    state.posts.find((p) => p.id === Number(id))
  );
  const navigation = useNavigation();
  const isDeleting = navigation.formAction === `/posts/${id}/delete`;

  if (!post) return null;

  return (
    <section>
      <div className="page-heading">
        <h1>Delete post</h1>
        <span className="pill danger-pill">DELETE /posts/{post.id}</span>
      </div>

      <div className="confirm-card">
        <p>You're about to permanently delete:</p>
        <h3>{post.title}</h3>
        <p className="post-body">{post.body}</p>

        <div className="post-actions">
          <Form method="post">
            <button type="submit" className="danger" disabled={isDeleting}>
              {isDeleting ? "Deleting…" : "Confirm delete"}
            </button>
          </Form>
          <Link to={`/posts/${post.id}`}>Cancel</Link>
        </div>
      </div>
    </section>
  );
}
