import { Link, Outlet, useNavigation } from "react-router";

// This component renders once and stays mounted while you navigate
// between pages. <Outlet /> is where the matched child route's page
// renders. This is the same idea as a layout in a banking app shell —
// the header/sidebar don't remount every time you click a menu item.
export default function RootLayout() {
  const navigation = useNavigation();
  // navigation.state is "idle" | "loading" | "submitting".
  // React Router flips this automatically whenever any loader or
  // action for the next page is in flight — no extra state needed.
  const isNavigating = navigation.state !== "idle";

  return (
    <div className="app-shell">
      <header className="topbar">
        <Link to="/" className="brand">
          Posts CRUD Demo
        </Link>
        <nav>
          <Link to="/">All posts</Link>
          <Link to="/posts/new">+ New post</Link>
        </nav>
      </header>

      {/* A thin bar so any navigation (loading a page, or running an
          action) is visible, without every page having to build its
          own spinner. */}
      <div className={`nav-progress ${isNavigating ? "active" : ""}`} />

      <main className="page">
        <Outlet />
      </main>
    </div>
  );
}
