import { Link, useParams } from "react-router";

// This boundary is attached to the /posts/:id, /posts/:id/edit and
// /posts/:id/delete routes. If someone opens /posts/9999 (JSONPlaceholder
// only has ids 1–100), the loader throws a 404 Response, and React Router
// renders THIS boundary instead of RootErrorBoundary — because it's the
// closest one to where the error happened.
//
// That's the key idea of nested error boundaries: the nav bar and page
// shell (from RootLayout) stay on screen. Only the broken part of the
// page is replaced with a friendly message.
export default function PostNotFoundBoundary() {
  const { id } = useParams();

  return (
    <div className="error-panel">
      <h1>Post not found</h1>
      <p>There's no post with id "{id}".</p>
      <Link to="/">Back to all posts</Link>
    </div>
  );
}
