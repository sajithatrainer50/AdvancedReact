import type { Post, PostInput } from "../types";

// JSONPlaceholder is a free fake REST API. No key needed.
// It accepts GET / POST / PUT / DELETE and always answers with a
// success-shaped response — but it does NOT actually save anything.
// (More on why that matters in GUIDE.md — it's the reason this project
// also keeps its own copy of the data in Zustand.)
const BASE_URL = "https://jsonplaceholder.typicode.com/posts";

// Every function below does the same three things:
// 1. call fetch()
// 2. if the response is not ok, throw a Response so React Router's
//    error boundaries can catch it (this is the built-in v7 pattern)
// 3. otherwise return the parsed JSON, typed as a Post

async function assertOk(res: Response) {
  if (!res.ok) {
    throw new Response(res.statusText || "Request failed", {
      status: res.status,
    });
  }
}

// GET /posts  → used by the List page
export async function getAllPosts(): Promise<Post[]> {
  const res = await fetch(BASE_URL);
  await assertOk(res);
  const all: Post[] = await res.json();
  // The real API has 100 posts. That's plenty for a demo list,
  // so we just take the first 10 to keep the page readable.
  return all.slice(0, 10);
}

// GET /posts/:id  → used by the Detail and Edit pages
export async function getPostById(id: number): Promise<Post> {
  const res = await fetch(`${BASE_URL}/${id}`);
  await assertOk(res);
  return res.json();
}

// POST /posts  → used by the Create page
export async function createPost(input: PostInput): Promise<Post> {
  const res = await fetch(BASE_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...input, userId: 1 }),
  });
  await assertOk(res);
  return res.json();
}

// PUT /posts/:id  → used by the Edit page
export async function updatePost(id: number, input: PostInput): Promise<Post> {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, userId: 1, ...input }),
  });
  await assertOk(res);
  return res.json();
}

// DELETE /posts/:id  → used by the Delete page
export async function deletePost(id: number): Promise<void> {
  const res = await fetch(`${BASE_URL}/${id}`, { method: "DELETE" });
  await assertOk(res);
}
