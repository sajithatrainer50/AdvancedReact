import { create } from "zustand";
import type { Post } from "../types";

// What's deliberately NOT in here: isLoading, error, isSubmitting.
// React Router's loaders/actions already track that for us
// (via useNavigation) — duplicating it in Zustand would just mean
// two sources of truth that can go out of sync.
//
// This store's only job: hold the posts every page has agreed to share.
interface PostStore {
  posts: Post[];
  // True once the LIST loader has fetched the full list at least once.
  // Without this, a deep link straight into /posts/5 would put exactly
  // one post in `posts`, and the list loader would wrongly assume it
  // already had "everything" and skip fetching the rest.
  listLoaded: boolean;

  // Called by loaders after a fetch, and by actions after a
  // create/update, so every page reading `posts` sees the same data.
  setPosts: (posts: Post[]) => void;
  upsertPost: (post: Post) => void;
  removePost: (id: number) => void;
}

export const usePostStore = create<PostStore>((set) => ({
  posts: [],
  listLoaded: false,

  setPosts: (posts) => set({ posts, listLoaded: true }),

  upsertPost: (post) =>
    set((state) => {
      const exists = state.posts.some((p) => p.id === post.id);
      return {
        posts: exists
          ? state.posts.map((p) => (p.id === post.id ? post : p))
          : [post, ...state.posts],
      };
    }),

  removePost: (id) =>
    set((state) => ({ posts: state.posts.filter((p) => p.id !== id) })),
}));
