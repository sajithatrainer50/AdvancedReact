// This is the shape of a single post, exactly as JSONPlaceholder returns it.
// Keeping one shared type means every page, the store, and the API file
// all agree on what a "post" looks like.
export interface Post {
  id: number;
  userId: number;
  title: string;
  body: string;
}

// What a create/edit form actually collects from the user.
// (No id, no userId — the server/store assigns those.)
export interface PostInput {
  title: string;
  body: string;
}
