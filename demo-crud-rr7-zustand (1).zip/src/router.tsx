import { createBrowserRouter } from "react-router";

import RootLayout from "./routes/RootLayout";
import RootErrorBoundary from "./routes/RootErrorBoundary";
import PostNotFoundBoundary from "./routes/PostNotFoundBoundary";

import PostsListPage, { listLoader } from "./routes/PostsListPage";
import PostDetailPage, { postDetailLoader } from "./routes/PostDetailPage";
import CreatePostPage, { createAction } from "./routes/CreatePostPage";
import EditPostPage, { updateAction } from "./routes/EditPostPage";
import DeletePostPage, { deleteAction } from "./routes/DeletePostPage";

// One route object per page. `loader` runs before the page renders
// (for GET-style reads), `action` runs when a <Form> on that page is
// submitted (for POST/PUT/DELETE-style writes). `Component` and
// `ErrorBoundary` are React 19-style function components — v7 route
// objects accept components directly, no createElement / JSX needed
// at this layer.
export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    // Catches anything not caught by a more specific boundary below.
    ErrorBoundary: RootErrorBoundary,
    children: [
      {
        index: true, // matches exactly "/"
        Component: PostsListPage,
        loader: listLoader, // GET /posts
      },
      {
        path: "posts/:id",
        Component: PostDetailPage,
        loader: postDetailLoader, // GET /posts/:id
        ErrorBoundary: PostNotFoundBoundary,
      },
      {
        path: "posts/new",
        Component: CreatePostPage,
        action: createAction, // POST /posts
      },
      {
        path: "posts/:id/edit",
        Component: EditPostPage,
        loader: postDetailLoader, // reused — an edit form needs GET first
        action: updateAction, // PUT /posts/:id
        ErrorBoundary: PostNotFoundBoundary,
      },
      {
        path: "posts/:id/delete",
        Component: DeletePostPage,
        loader: postDetailLoader, // reused — need the post to confirm delete
        action: deleteAction, // DELETE /posts/:id
        ErrorBoundary: PostNotFoundBoundary,
      },
    ],
  },
]);
